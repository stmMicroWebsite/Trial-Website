Thanks for downloading this theme!

Theme Name: Maxim
Theme URL: https://bootstrapmade.com/maxim-free-onepage-bootstrap-theme/
Author: BootstrapMade.com
Author URL: https://bootstrapmade.com